package icetask2;

import java.util.ArrayList;
import java.util.Scanner;

// Base class for Patients
class Patient {
    protected String name;
    protected int age;
    protected String gender;

    // Constructor to initialize the patient details
    public Patient(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    // Method to display patient details
    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age + ", Gender: " + gender);
    }
}

// Subclass for Female patients
class FemalePatient extends Patient {
    public FemalePatient(String name, int age) {
        super(name, age, "Female");
    }

    // Method to check eligibility based on age
    public void checkEligibility() {
        if (age < 18) {
            System.out.println(name + " is not eligible for treatment at the emergency room. Please transfer to Durban (DBN) Hospital.");
        } else {
            System.out.println(name + " is eligible for treatment at the Durban (DBN) Hospital.");
        }
    }
}

// Subclass for Male patients
class MalePatient extends Patient {
    private boolean hasChronicDisorder;

    public MalePatient(String name, int age, boolean hasChronicDisorder) {
        super(name, age, "Male");
        this.hasChronicDisorder = hasChronicDisorder;
    }

    // Method to check eligibility based on age and chronic disorder
    public void checkEligibility() {
        if (age > 18) {
            if (hasChronicDisorder) {
                System.out.println(name + " has a chronic disorder and should be transferred to Johannesburg (JHB) Hospital.");
            } else {
                System.out.println(name + " is eligible for treatment at the Durban (DBN) Hospital.");
            }
        } else {
            System.out.println(name + " is not eligible for treatment at the emergency room.");
        }
    }
}

// Main class with the menu and login system
public class Icetask2 {

    // Mock data of patients
    private static ArrayList<Patient> patients = new ArrayList<>();
    
    static {
        patients.add(new FemalePatient("Alice", 17));
        patients.add(new FemalePatient("Clara", 20));
        patients.add(new MalePatient("John", 22, true));
        patients.add(new MalePatient("Mike", 16, false));
        patients.add(new MalePatient("Bob", 19, false));
    }

    // Method to handle the login
    private static boolean login(String username, String password) {
        return username.equals("Admin") && password.equals("St@a77");
    }

    // Method to search for a patient by name
    private static Patient searchPatient(String name) {
        for (Patient patient : patients) {
            if (patient.name.equalsIgnoreCase(name)) {
                return patient;
            }
        }
        return null; // Return null if patient is not found
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Login system
        System.out.println("Please enter your username:");
        String username = scanner.nextLine();
        System.out.println("Please enter your password:");
        String password = scanner.nextLine();

        if (!login(username, password)) {
            System.out.println("Invalid login. Please try again.");
            return; // Exit the program if login fails
        }

        System.out.println("Login successful!");

        // Menu system
        while (true) {
            System.out.println("\n1. Search Patient by Name");
            System.out.println("2. Display All Patients and Their Eligibility");
            System.out.println("3. Exit");
            System.out.println("Enter your choice:");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1: // Search for a patient
                    System.out.println("Enter the name of the patient to search:");
                    String name = scanner.nextLine();
                    Patient patient = searchPatient(name);
                    if (patient != null) {
                        patient.displayInfo();
                        if (patient instanceof FemalePatient) {
                            ((FemalePatient) patient).checkEligibility();
                        } else if (patient instanceof MalePatient) {
                            ((MalePatient) patient).checkEligibility();
                        }
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;

                case 2: // Display all patients and their eligibility
                    for (Patient p : patients) {
                        p.displayInfo();
                        if (p instanceof FemalePatient) {
                            ((FemalePatient) p).checkEligibility();
                        } else if (p instanceof MalePatient) {
                            ((MalePatient) p).checkEligibility();
                        }
                    }
                    break;

                case 3: // Exit the program
                    System.out.println("Exiting the system.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}

